import json
import threading
from datetime import datetime
from utils.file_manager import FileManager

class Memory:
    def __init__(self):
        self.file_manager = FileManager()
        self.knowledge_file = "data/nox_knowledge.json"
        self.knowledge_base = self._load_knowledge()
        self.lock = threading.RLock()
        
    def _load_knowledge(self):
        return self.file_manager.read_json(self.knowledge_file, {})
        
    def learn_fact(self, topic, info):
        with self.lock:
            self.knowledge_base[topic] = {
                "info": info,
                "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            self.file_manager.write_json(self.knowledge_file, self.knowledge_base)
            
    def get_fact(self, topic):
        """Retrieve knowledge by topic (case-insensitive)"""
        topic_lower = topic.lower()
        for key, value in self.knowledge_base.items():
            if key.lower() == topic_lower:
                return value["info"]
        return None
        
    def save(self):
        with self.lock:
            self.file_manager.write_json(self.knowledge_file, self.knowledge_base)

# Create global instance for backward compatibility
memory_instance = Memory()

# Standalone function for direct import
def get_fact(topic):
    """Standalone function to get fact from knowledge base"""
    return memory_instance.get_fact(topic)

def learn_fact(topic, info):
    """Standalone function to learn new fact"""
    return memory_instance.learn_fact(topic, info)