import json
import threading
from datetime import datetime
from utils.file_manager import FileManager

class ContextManager:
    def __init__(self):
        self.file_manager = FileManager()
        self.context_file = "data/system_state.json"
        self.current_context = self._load_context()
        self.lock = threading.RLock()
        
    def _load_context(self):
    """Load current context from file with error recovery"""
    default_context = {
        "last_activity": None,
        "current_context": {},
        "system_status": "ready"
    }
    
    context_data = self.file_manager.read_json(self.context_file, default_context)
    
    # Ensure all required keys exist
    if "current_context" not in context_data:
        context_data["current_context"] = {}
    if "system_status" not in context_data:
        context_data["system_status"] = "ready"
    if "last_activity" not in context_data:
        context_data["last_activity"] = None
        
    return context_data
        
    def update_context(self, key, value):
        """Update a specific context value"""
        with self.lock:
            self.current_context["current_context"][key] = value
            self.current_context["last_activity"] = datetime.now().isoformat()
            self._save_context()
            
    def get_context(self, key, default=None):
        """Get a specific context value"""
        return self.current_context["current_context"].get(key, default)
        
    def set_system_status(self, status):
        """Update system status"""
        with self.lock:
            self.current_context["system_status"] = status
            self.current_context["last_activity"] = datetime.now().isoformat()
            self._save_context()
            
    def get_system_status(self):
        """Get current system status"""
        return self.current_context["system_status"]
        
    def update_activity(self):
        """Update last activity timestamp"""
        with self.lock:
            self.current_context["last_activity"] = datetime.now().isoformat()
            self._save_context()
            
    def _save_context(self):
        """Save context to file"""
        self.file_manager.write_json(self.context_file, self.current_context)
        
    def get_conversation_context(self, limit=5):
        """Get recent conversation context for AI"""
        from core.history_manager import HistoryManager
        history_manager = HistoryManager()
        recent_conversations = history_manager.get_recent_conversations(limit)
        
        context = ""
        for conv in recent_conversations:
            context += f"{conv.get('role', 'user')}: {conv.get('content', '')}\n"
            
        return context.strip()

# Global instance for easy access
context_manager = ContextManager()