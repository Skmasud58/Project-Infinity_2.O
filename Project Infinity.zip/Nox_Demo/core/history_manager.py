import json
from datetime import datetime
from utils.file_manager import FileManager

class HistoryManager:
    def __init__(self):
        self.file_manager = FileManager()
        self.history_file = "data/conversation_history.json"
        self.current_session = {
            "session_id": self._generate_session_id(),
            "start_time": datetime.now().isoformat(),
            "conversations": []
        }
        
    def _generate_session_id(self):
        return f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
    def add_conversation(self, role, content, emotion=None, context=None):
        conversation = {
            "timestamp": datetime.now().isoformat(),
            "role": role,
            "content": content,
            "emotion": emotion,
            "context": context or {}
        }
        
        self.current_session["conversations"].append(conversation)
        self._save_current_session()
        
    def _save_current_session(self):
        history_data = self.file_manager.read_json(self.history_file, {"sessions": []})
        history_data["sessions"].append(self.current_session)
        history_data["last_session_id"] = self.current_session["session_id"]
        self.file_manager.write_json(self.history_file, history_data)
        
    def get_recent_conversations(self, count=5):
    all_conversations = []
    try:
        history_data = self.file_manager.read_json(self.history_file, {"sessions": []})
        
        for session in history_data.get("sessions", [])[-3:]:
            if isinstance(session, dict) and "conversations" in session:
                all_conversations.extend(session.get("conversations", []))
    except Exception as e:
        print(f"[History Load Error] {e}")
        
    return all_conversations[-count:]