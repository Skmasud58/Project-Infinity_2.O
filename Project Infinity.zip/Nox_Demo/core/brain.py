import re
from datetime import datetime, timedelta
from core.processor import CommandProcessor
from core.memory import Memory
from core.context_manager import ContextManager
from core.history_manager import HistoryManager

class Brain:
    def __init__(self):
        self.processor = CommandProcessor()
        self.memory = Memory()
        self.context = ContextManager()
        self.history = HistoryManager()
        
    def process_command(self, command):
        command = command.lower().strip()
        
        # Add to conversation history
        self.history.add_conversation("user", command)
        
        # Process command
        response = self.processor.process(command)
        
        # Add response to history
        self.history.add_conversation("assistant", response)
        
        return response