import re
import random
from datetime import datetime
from ai_modules.chat.gpt_chat import ask_gemini
from ai_modules.chat.emotion_analysis import emotional_response, deep_emotional_response
from ai_modules.productivity.reminder import schedule_reminder, dismiss_next_reminder
from ai_modules.productivity.alarm import schedule_alarm, dismiss_next_alarm
from ai_modules.system.system_info import system_info, what_is_my_ip
from ai_modules.automation.browser_auto import play_movies, play_song
from utils.helper import get_weather, fetch_news, take_screenshot
from utils.network import what_is_my_live_location
from core.memory import get_fact

class CommandProcessor:
    def process(self, command):
        # Emotional detection first
        if deep_emotional_response(command):
            return ""
            
        # System commands
        if any(phrase in command for phrase in ["how are you", "how's it going"]):
            return self._friendly_response()
            
        elif "system information" in command or "system info" in command:
            system_info()
            return ""
            
        elif "what is my ip" in command:
            ip = what_is_my_ip()
            return f"Your IP address is {ip}" if ip else "Sorry, I couldn't detect your IP address."
            
        # Alarm/Reminder commands
        elif command.startswith("set alarm"):
            return self._handle_alarm(command)
            
        elif command.startswith("set reminder"):
            return self._handle_reminder(command)
            
        elif any(phrase in command for phrase in ["stop alarm", "dismiss alarm"]):
            dismiss_next_alarm()
            return "Okay sir, I have stopped that alarm."
            
        # File operations
        elif any(op in command for op in ["open folder", "create folder", "create file", "copy file"]):
            from utils.file_manager import handle_file_command
            handle_file_command(command)
            return ""
            
        # Check memory/knowledge base first
        fact = get_fact(command)
        if fact:
            return fact
            
        # Fallback to AI
        ai_response = ask_gemini(command)
        return emotional_response(command, ai_response)
        
    def _friendly_response(self):
        responses = [
            "I'm doing great — just finished reorganizing your system files for fun. You know, typical AI stuff!",
            "Everything's running smooth here. But honestly, I missed talking to you.",
            "Running perfectly fine, sir! Though I wouldn't mind a coffee break... if I had taste buds."
        ]
        return random.choice(responses)
        
    def _handle_alarm(self, command):
        from ai_modules.productivity.alarm import parse_time_from_text
        dt = parse_time_from_text(command.replace("set alarm", "").strip())
        if dt:
            schedule_alarm(dt, "Alarm", kind="alarm")
            return f"Alarm set for {dt.strftime('%b %d, %Y %I:%M %p')}"
        return "Sorry sir, I couldn't parse the time."
        
    def _handle_reminder(self, command):
        from ai_modules.productivity.reminder import parse_time_from_text
        dt = parse_time_from_text(command.replace("set reminder", "").strip())
        if dt:
            schedule_reminder(dt, "Reminder", kind="reminder")
            return f"Reminder set for {dt.strftime('%b %d, %Y %I:%M %p')}"
        return "Sorry sir, I couldn't parse the time."