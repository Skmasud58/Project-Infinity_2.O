import threading
import time
from datetime import datetime
from core.brain import Brain
from voice.listener import listen_for_command
from voice.speaker import speak, stop_speaking
from voice.wakeword import wake_word_detected, start_wake_word_listener
from utils.data_initializer import DataInitializer

def wish_me():
    hour = datetime.now().hour
    if 0 <= hour < 12:
        speak("Good morning sir! Nox reporting in — everything's running smoothly. What would you like me to handle first?")
    elif 12 <= hour < 18:
        speak("Good afternoon sir! Nox reporting in — everything's running smoothly. What would you like me to handle first?")
    else:
        speak("Good evening sir! Nox reporting in — everything's running smoothly. What would you like me to handle first?")

def main():
    # Initialize data structure first
    initializer = DataInitializer()
    initializer.initialize_all()
    
    # Start wake word listener
    start_wake_word_listener()
    
    # Initialize brain
    brain = Brain()
    
    wish_me()
    
    # Main loop
    while True:
        wake_word_detected.wait()
        wake_word_detected.clear()
        stop_speaking()
        
        speak("Yes sir, I am here. Please tell me...")
        command = listen_for_command()
        
        if command == "none":
            continue
            
        brain.process_command(command)

if __name__ == "__main__":
    main()