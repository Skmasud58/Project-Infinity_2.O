import asyncio
import threading
import os
import playsound
import edge_tts
from config.voice_config import *

speak_lock = threading.RLock()
stop_speaking_flag = threading.Event()

async def _speak_async(text):
    """Internal async function to handle Edge TTS."""
    stop_speaking_flag.clear()
    safe_text = text.replace("₹", "rupees")
    print(f"Nox: {safe_text}")

    communicate = edge_tts.Communicate(
        safe_text,
        voice=VOICE_NAME,
        rate=VOICE_RATE
    )

    temp_file = "nox_temp.mp3"
    await communicate.save(temp_file)
    
    playsound.playsound(temp_file)
    os.remove(temp_file)

def speak(text):
    """Thread-safe wrapper to speak text immediately."""
    with speak_lock:
        stop_speaking_flag.set()
        asyncio.run(_speak_async(text))

def stop_speaking():
    """Stop any speaking in progress."""
    if not stop_speaking_flag.is_set():
        stop_speaking_flag.set()