import speech_recognition as sr
from config.voice_config import *

def listen_for_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for command...")
        r.pause_threshold = PAUSE_THRESHOLD
        audio = r.listen(source, timeout=LISTENER_TIMEOUT, phrase_time_limit=PHRASE_TIME_LIMIT)
    try:
        query = r.recognize_google(audio, language=LANGUAGE).lower()
        print(f"You said: {query}")
        return query
    except:
        return "none"