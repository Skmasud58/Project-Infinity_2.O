import speech_recognition as sr
import threading
from config.settings import WAKE_WORDS
from config.voice_config import *

wake_word_detected = threading.Event()

def wake_word_listener():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source, duration=1)
        print("Wake word listener active...")
        while True:
            try:
                audio = r.listen(source, timeout=5, phrase_time_limit=5)
                query = r.recognize_google(audio, language=LANGUAGE).lower()
                if any(w in query for w in WAKE_WORDS):
                    print(f"Wake word detected: {query}")
                    from voice.speaker import stop_speaking
                    stop_speaking()
                    wake_word_detected.set()
            except sr.WaitTimeoutError:
                continue
            except sr.UnknownValueError:
                continue
            except Exception as e:
                print(f"[Wake Word Error] {e}")

def start_wake_word_listener():
    """Start the wake word listener in a daemon thread."""
    threading.Thread(target=wake_word_listener, daemon=True).start()