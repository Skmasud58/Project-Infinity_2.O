import psutil
import threading
import time
from voice.speaker import speak

def get_battery_status():
    """Get current battery status"""
    battery = psutil.sensors_battery()
    if battery:
        percent = battery.percent
        plugged = battery.power_plugged
        status = "charging" if plugged else "not charging"
        return f"Battery: {percent}% and currently {status}"
    return "No battery detected on this system."

def battery_monitor(threshold=20):
    """Monitor battery level and alert when low"""
    while True:
        battery = psutil.sensors_battery()
        if battery and not battery.power_plugged and battery.percent <= threshold:
            speak(f"Warning! Battery level is {battery.percent}%. Please connect to power source.")
        time.sleep(300)  # Check every 5 minutes

# Start battery monitoring
threading.Thread(target=battery_monitor, daemon=True).start()