import psutil
import platform
import socket
import GPUtil
import subprocess
import threading
import time
from voice.speaker import speak

def get_battery_status():
    """Get current battery status"""
    battery = psutil.sensors_battery()
    if battery:
        percent = battery.percent
        plugged = battery.power_plugged
        status = "charging" if plugged else "not charging"
        return f"Battery: {percent}% and currently {status}"
    return "No battery detected on this system."

def battery_monitor(threshold=20):
    """Monitor battery level and alert when low"""
    while True:
        battery = psutil.sensors_battery()
        if battery and not battery.power_plugged and battery.percent <= threshold:
            speak(f"Warning! Battery level is {battery.percent}%. Please connect to power source.")
        time.sleep(300)  # Check every 5 minutes

def system_info():
    """Get complete system information"""
    try:
        # Basic system info
        uname = platform.uname()
        cpu_percent = psutil.cpu_percent(interval=0.5)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        battery = psutil.sensors_battery()

        # CPU details
        cpu_count = psutil.cpu_count(logical=False)
        cpu_logical = psutil.cpu_count(logical=True)
        cpu_freq = psutil.cpu_freq()

        # GPU info
        gpus = GPUtil.getGPUs()
        gpu_info = []
        for gpu in gpus:
            gpu_info.append(f"{gpu.name} with {gpu.memoryTotal} MB VRAM")

        # Motherboard info
        try:
            motherboard = subprocess.check_output(
                "wmic baseboard get product,Manufacturer", shell=True
            ).decode().split("\n")[1].strip()
        except:
            motherboard = "Unknown"

        # IP Address
        ip_address = what_is_my_ip()

        # Speak system info
        speak("Here is your complete system configuration:")
        speak(f"Operating System: {uname.system} {uname.release}")
        speak(f"Device Name: {uname.node}")
        speak(f"Processor: {uname.processor}")
        speak(f"Cores: {cpu_count} physical, {cpu_logical} logical")
        speak(f"Frequency: {cpu_freq.current:.2f} MHz")
        speak(f"CPU Usage: {cpu_percent}%")
        speak(f"RAM: {ram.total // (1024 ** 3)} GB, Usage: {ram.percent}%")
        speak(f"Disk: {disk.total // (1024 ** 3)} GB, Used: {disk.percent}%")

        if gpu_info:
            speak(f"Graphics Card(s): {'; '.join(gpu_info)}")
        else:
            speak("No dedicated GPU detected.")

        speak(f"Motherboard: {motherboard}")

        if battery:
            status = "charging" if battery.power_plugged else "not charging"
            speak(f"Battery: {battery.percent}% and currently {status}")
        else:
            speak("No battery detected on this system.")

        speak(f"IP Address: {ip_address}")

    except Exception as e:
        speak(f"Sorry sir, I encountered an error while fetching system configuration: {e}")

def what_is_my_ip():
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception as e:
        print(f"Error detecting IP: {e}")
        return "Unable to detect"

def performance_monitor(threshold_cpu=80, threshold_ram=85):
    """Monitor system performance"""
    while True:
        cpu = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory().percent

        if cpu > threshold_cpu:
            speak(f"Warning! CPU usage is high at {cpu} percent.")
        if ram > threshold_ram:
            speak(f"Warning! Memory usage is high at {ram} percent.")

        time.sleep(5)

# Start performance monitoring
threading.Thread(target=performance_monitor, daemon=True).start()
# Start battery monitoring
threading.Thread(target=battery_monitor, daemon=True).start()