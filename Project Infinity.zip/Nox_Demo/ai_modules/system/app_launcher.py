import os
import subprocess
import webbrowser
from voice.speaker import speak

def open_application(app_name):
    """Open applications based on voice command"""
    app_commands = {
        "explorer": "explorer",
        "downloads": lambda: os.startfile(os.path.join(os.path.expanduser("~"), "Downloads")),
        "documents": lambda: os.startfile(os.path.join(os.path.expanduser("~"), "Documents")),
        "pictures": lambda: os.startfile(os.path.join(os.path.expanduser("~"), "Pictures")),
        "device manager": "devmgmt.msc",
        "system configuration": "msconfig",
        "calculator": "calc",
        "notepad": "notepad",
        "command prompt": "start cmd",
        "powershell": "start powershell",
        "control panel": "control",
        "settings": "start ms-settings:",
        "task manager": "taskmgr",
        "camera": "start microsoft.windows.camera:",
        "chrome": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        "edge": "start msedge",
        "spotify": "spotify:",
        "word": r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
        "excel": r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
        "powerpoint": r"C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE",
        "vs code": r"C:\Users\skmas\AppData\Local\Programs\Microsoft VS Code\Code.exe"
    }

    website_commands = {
        "youtube": "https://youtube.com",
        "google": "https://google.com",
        "whatsapp": "https://web.whatsapp.com",
        "telegram": "https://web.telegram.org",
        "facebook": "https://facebook.com",
        "chatgpt": "https://chat.openai.com"
    }

    app_name = app_name.lower().replace("open ", "").strip()

    try:
        if app_name in app_commands:
            speak(f"Opening {app_name}...")
            command = app_commands[app_name]
            
            if callable(command):
                command()
            elif command.startswith("http"):
                webbrowser.open(command)
            else:
                if "start " in command:
                    os.system(command)
                else:
                    subprocess.Popen(command, shell=False)
                    
        elif app_name in website_commands:
            speak(f"Opening {app_name}...")
            webbrowser.open(website_commands[app_name])
            
        else:
            speak(f"Sorry sir, I don't know how to open {app_name}")
            
    except Exception as e:
        speak(f"Failed to open {app_name}: {str(e)}")

def system_command(command):
    """Execute system commands"""
    commands = {
        "check update": "start ms-settings:windowsupdate",
        "shut down": "shutdown /s /t 5",
        "restart": "shutdown /r /t 5"
    }
    
    if command in commands:
        speak(f"Executing {command}...")
        os.system(commands[command])
    else:
        speak("Unknown system command")