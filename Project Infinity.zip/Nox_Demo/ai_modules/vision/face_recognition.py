import cv2
import face_recognition
import pickle
import os
from datetime import datetime

class FaceRecognizer:
    def __init__(self):
        self.known_faces_file = "assets/models/known_faces.dat"
        self.known_faces = self._load_known_faces()
        
    def _load_known_faces(self):
        """Load known faces from file"""
        if os.path.exists(self.known_faces_file):
            with open(self.known_faces_file, 'rb') as f:
                return pickle.load(f)
        return {}
        
    def _save_known_faces(self):
        """Save known faces to file"""
        os.makedirs(os.path.dirname(self.known_faces_file), exist_ok=True)
        with open(self.known_faces_file, 'wb') as f:
            pickle.dump(self.known_faces, f)
            
    def add_face(self, name, image_path):
        """Add a new face to recognition database"""
        image = face_recognition.load_image_file(image_path)
        encodings = face_recognition.face_encodings(image)
        
        if encodings:
            self.known_faces[name] = encodings[0]
            self._save_known_faces()
            return True
        return False
        
    def recognize_face(self, image_path):
        """Recognize face in image"""
        if not self.known_faces:
            return "No faces in database"
            
        unknown_image = face_recognition.load_image_file(image_path)
        unknown_encoding = face_recognition.face_encodings(unknown_image)
        
        if not unknown_encoding:
            return "No face detected"
            
        for name, known_encoding in self.known_faces.items():
            results = face_recognition.compare_faces([known_encoding], unknown_encoding[0])
            if results[0]:
                return name
                
        return "Unknown person"