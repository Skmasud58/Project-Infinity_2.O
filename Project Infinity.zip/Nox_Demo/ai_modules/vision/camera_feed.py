import cv2
from voice.speaker import speak

def open_camera():
    """Open webcam feed"""
    try:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            speak("Cannot open camera")
            return
            
        speak("Camera opened successfully. Press 'q' to close.")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                speak("Can't receive frame. Exiting...")
                break
                
            cv2.imshow('Nox Camera', frame)
            if cv2.waitKey(1) == ord('q'):
                break
                
        cap.release()
        cv2.destroyAllWindows()
        speak("Camera closed")
        
    except Exception as e:
        speak(f"Error opening camera: {str(e)}")