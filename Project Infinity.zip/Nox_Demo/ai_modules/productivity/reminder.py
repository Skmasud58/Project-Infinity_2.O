import json
import time
import threading
import re
from datetime import datetime, time as dtime, timedelta
from voice.speaker import speak
from voice.wakeword import wake_word_detected
from utils.file_manager import FileManager
from config.settings import REMINDER_FILE

file_manager = FileManager()
reminder_lock = threading.RLock()
reminder_monitor_stop = threading.Event()

def load_reminders():
    return file_manager.read_json(REMINDER_FILE, [])

def save_reminders(reminders):
    file_manager.write_json(REMINDER_FILE, reminders)

def _now():
    return datetime.now()

def parse_time_from_text(text):
    """Parse natural language time text into datetime object"""
    text = text.strip().lower().replace(".", "").replace(",", "")
    now = _now()

    # Absolute ISO format
    m = re.search(r"(\d{4}-\d{1,2}-\d{1,2})\s+(\d{1,2}:\d{2}(?::\d{2})?)", text)
    if m:
        date_part = m.group(1)
        time_part = m.group(2)
        try:
            return datetime.fromisoformat(f"{date_part} {time_part}")
        except:
            pass

    # Today/Tomorrow with time
    m = re.search(r"(today|tomorrow)\s+(\d{1,2}(?::\d{2})?\s*(am|pm)?)", text)
    if m:
        day = m.group(1)
        time_str = m.group(2)
        t = _parse_time_simple(time_str)
        if t:
            target_date = now.date() if day == "today" else (now + timedelta(days=1)).date()
            return datetime.combine(target_date, t)

    # Time only
    m = re.search(r"(\d{1,2}:\d{2}\s*(am|pm)?)", text)
    if m:
        t = _parse_time_simple(m.group(1))
        if t:
            candidate = datetime.combine(now.date(), t)
            if candidate <= now:
                candidate += timedelta(days=1)
            return candidate

    return None

def _parse_time_simple(tstr):
    """Parse time string to time object"""
    tstr = tstr.strip().lower().replace(" ", "")
    try:
        m = re.match(r"^(\d{1,2})(?::(\d{2}))?(am|pm)?$", tstr)
        if not m:
            return None
        hour = int(m.group(1))
        minute = int(m.group(2) or 0)
        ampm = m.group(3)
        if ampm:
            if ampm == "pm" and hour != 12:
                hour += 12
            if ampm == "am" and hour == 12:
                hour = 0
        if 0 <= hour < 24 and 0 <= minute < 60:
            return dtime(hour, minute)
    except:
        return None
    return None

def schedule_reminder(trigger_dt, message, kind="reminder", snooze_minutes=0):
    """Schedule a new reminder"""
    with reminder_lock:
        reminders = load_reminders()
        reminder_id = int(time.time() * 1000)
        reminder = {
            "id": reminder_id,
            "type": kind,
            "time_iso": trigger_dt.strftime("%Y-%m-%dT%H:%M:%S"),
            "message": message,
            "snooze_minutes": snooze_minutes,
            "triggered": False,
            "dismissed": False
        }
        reminders.append(reminder)
        save_reminders(reminders)
    
    speak(f"Reminder set for {trigger_dt.strftime('%b %d, %Y %I:%M %p')}")
    return reminder

def _announce_reminder_loop(reminder):
    """Announce reminder repeatedly until dismissed"""
    REPEAT_SECONDS = 25
    reminder_id = reminder["id"]

    while True:
        with reminder_lock:
            reminders = load_reminders()
            matches = [a for a in reminders if a["id"] == reminder_id]
            if not matches:
                return
            current = matches[0]
            if current.get("dismissed", False):
                return

        try:
            now_time = datetime.now().strftime("%I:%M %p")
            reminder_message = current["message"]
            spoken_message = f"Sir, now time is {now_time}. You have set a reminder to {reminder_message}."
            print(f"[REMINDER] {spoken_message}")
            speak(spoken_message)
        except Exception as e:
            print("[Reminder Announce Error]", e)

        start = time.time()
        while time.time() - start < REPEAT_SECONDS:
            with reminder_lock:
                reminders = load_reminders()
                m = [a for a in reminders if a["id"] == reminder_id]
                if not m or m[0].get("dismissed", False):
                    return
            if wake_word_detected.is_set():
                return
            time.sleep(0.5)

def reminder_monitor():
    """Monitor and trigger reminders"""
    while not reminder_monitor_stop.is_set():
        try:
            now = _now()
            with reminder_lock:
                reminders = load_reminders()
                for reminder in reminders:
                    if reminder.get("dismissed", False):
                        continue
                    if not reminder.get("triggered", False):
                        reminder_dt = datetime.fromisoformat(reminder["time_iso"])
                        if now >= reminder_dt:
                            reminder["triggered"] = True
                            save_reminders(reminders)
                            t = threading.Thread(target=_announce_reminder_loop, args=(reminder,), daemon=True)
                            t.start()
        except Exception as e:
            print("[REMINDER Monitor Error]", e)
        time.sleep(5)

def dismiss_next_reminder():
    """Dismiss active reminder"""
    with reminder_lock:
        reminders = load_reminders()
        for a in reminders:
            if a.get("triggered", False) and not a.get("dismissed", False):
                a["dismissed"] = True
                save_reminders(reminders)
                speak("Okay sir, I have stopped that reminder.")
                return True
        speak("No active reminder to dismiss.")
        return False

# Start reminder monitor
threading.Thread(target=reminder_monitor, daemon=True).start()