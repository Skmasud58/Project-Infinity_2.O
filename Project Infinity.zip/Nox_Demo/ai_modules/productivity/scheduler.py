# Central scheduling system
# Coordinates between alarms, reminders, and other time-based tasks

from datetime import datetime

class Scheduler:
    def __init__(self):
        self.tasks = []
        
    def add_task(self, task_type, trigger_time, callback, data=None):
        """Add a scheduled task"""
        task = {
            'type': task_type,
            'trigger_time': trigger_time,
            'callback': callback,
            'data': data
        }
        self.tasks.append(task)
        
    def check_tasks(self):
        """Check and execute due tasks"""
        now = datetime.now()
        for task in self.tasks[:]:
            if now >= task['trigger_time']:
                try:
                    task['callback'](task['data'])
                    self.tasks.remove(task)
                except Exception as e:
                    print(f"Scheduler error: {e}")