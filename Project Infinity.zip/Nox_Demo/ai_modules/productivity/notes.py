import json
from utils.file_manager import FileManager

file_manager = FileManager()
NOTES_FILE = "data/user_notes.json"

def save_note(title, content):
    """Save a user note"""
    notes = file_manager.read_json(NOTES_FILE, [])
    notes.append({
        "title": title,
        "content": content,
        "timestamp": datetime.now().isoformat()
    })
    file_manager.write_json(NOTES_FILE, notes)
    
def get_notes():
    """Retrieve all notes"""
    return file_manager.read_json(NOTES_FILE, [])
    
def search_notes(keyword):
    """Search notes by keyword"""
    notes = get_notes()
    return [note for note in notes if keyword.lower() in note['title'].lower() or keyword.lower() in note['content'].lower()]