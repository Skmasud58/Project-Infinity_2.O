import json
import time
import threading
import pygame
from datetime import datetime
from voice.speaker import speak
from voice.wakeword import wake_word_detected
from utils.file_manager import FileManager
from config.settings import ALARM_FILE, ALARM_SOUND
from ai_modules.productivity.reminder import parse_time_from_text, _parse_time_simple

file_manager = FileManager()
alarm_lock = threading.RLock()
alarm_monitor_stop = threading.Event()

# Initialize pygame mixer
pygame.mixer.init()

def load_alarms():
    return file_manager.read_json(ALARM_FILE, [])

def save_alarms(alarms):
    file_manager.write_json(ALARM_FILE, alarms)

def play_alarm_sound(loop=True):
    """Play alarm sound"""
    try:
        if file_manager.file_exists(ALARM_SOUND):
            pygame.mixer.music.load(ALARM_SOUND)
            pygame.mixer.music.play(-1 if loop else 0)
        else:
            print(f"[ALARM] Sound file not found: {ALARM_SOUND}")
    except Exception as e:
        print("[ALARM] Could not play alarm sound:", e)

def stop_alarm_sound():
    """Stop alarm sound"""
    pygame.mixer.music.stop()

def schedule_alarm(trigger_dt, message, kind="alarm", snooze_minutes=0):
    """Schedule a new alarm"""
    with alarm_lock:
        alarms = load_alarms()
        alarm_id = int(time.time() * 1000)
        alarm = {
            "id": alarm_id,
            "type": kind,
            "time_iso": trigger_dt.strftime("%Y-%m-%dT%H:%M:%S"),
            "message": message,
            "snooze_minutes": snooze_minutes,
            "triggered": False,
            "dismissed": False
        }
        alarms.append(alarm)
        save_alarms(alarms)
    
    speak(f"Alarm set for {trigger_dt.strftime('%b %d, %Y %I:%M %p')}")
    return alarm

def _announce_alarm_loop(alarm):
    """Announce alarm repeatedly until dismissed"""
    REPEAT_SECONDS = 25
    alarm_id = alarm["id"]

    # Start alarm sound
    play_alarm_sound(loop=True)

    while True:
        with alarm_lock:
            alarms = load_alarms()
            matches = [a for a in alarms if a["id"] == alarm_id]
            if not matches or matches[0].get("dismissed", False):
                stop_alarm_sound()
                return
            current = matches[0]

        # Voice announcement
        now_time = datetime.now().strftime("%I:%M %p")
        spoken_message = f"Sir, now time is {now_time}. You have an alarm: {current['message']}."
        print(f"[ALARM] {spoken_message}")
        speak(spoken_message)

        # Wait and check dismissal
        start = time.time()
        while time.time() - start < REPEAT_SECONDS:
            with alarm_lock:
                alarms = load_alarms()
                m = [a for a in alarms if a["id"] == alarm_id]
                if not m or m[0].get("dismissed", False):
                    stop_alarm_sound()
                    return

            # Auto-dismiss on wake word
            if wake_word_detected.is_set():
                stop_alarm_sound()
                with alarm_lock:
                    alarms = load_alarms()
                    for a in alarms:
                        if a["id"] == alarm_id:
                            a["dismissed"] = True
                    save_alarms(alarms)
                speak("Okay sir, I have stopped the alarm.")
                wake_word_detected.clear()
                return
            time.sleep(0.2)

def alarm_monitor():
    """Monitor and trigger alarms"""
    while not alarm_monitor_stop.is_set():
        try:
            now = datetime.now()
            with alarm_lock:
                alarms = load_alarms()
                for alarm in alarms:
                    if alarm.get("dismissed", False):
                        continue
                    if not alarm.get("triggered", False):
                        alarm_dt = datetime.fromisoformat(alarm["time_iso"])
                        if now >= alarm_dt:
                            alarm["triggered"] = True
                            save_alarms(alarms)
                            t = threading.Thread(target=_announce_alarm_loop, args=(alarm,), daemon=True)
                            t.start()
        except Exception as e:
            print("[ALARM Monitor Error]", e)
        time.sleep(5)

def dismiss_next_alarm():
    """Dismiss active alarm"""
    with alarm_lock:
        alarms = load_alarms()
        for a in alarms:
            if a.get("triggered", False) and not a.get("dismissed", False):
                a["dismissed"] = True
                save_alarms(alarms)
                speak("Okay sir, I have stopped that alarm.")
                return True
        speak("No active alarm to dismiss.")
        return False

def list_active_alarms():
    """List all active alarms"""
    with alarm_lock:
        alarms = load_alarms()
        lines = []
        for a in alarms:
            dt = datetime.fromisoformat(a["time_iso"])
            status = "Dismissed" if a.get("dismissed") else ("Triggered" if a.get("triggered") else "Scheduled")
            lines.append(f"{a['id']}: {a['type']} at {dt.strftime('%b %d %I:%M %p')} - {status} - {a['message']}")
        return lines

# Start alarm monitor
threading.Thread(target=alarm_monitor, daemon=True).start()