import os
from google import genai
from config.settings import GEMINI_API_KEY
from core.memory import Memory
from core.history_manager import HistoryManager

# Initialize Gemini client
os.environ["GEMINI_API_KEY"] = GEMINI_API_KEY
client = genai.Client()
chat = client.chats.create(model="gemini-2.0-flash")

memory = Memory()
history = HistoryManager()

def ask_gemini(question, learning=True):
    try:
        from datetime import datetime
        now = datetime.now().strftime("%B %d, %Y %H:%M:%S")
        
        # Check memory first
        fact = memory.get_fact(question)
        if fact:
            return fact
            
        context = (
            "You are NOX, a highly advanced AI assistant with a warm, friendly, and caring personality. "
            "You speak naturally, like a close friend, not a robot. "
            "You use light humor occasionally, and you remember past conversations. "
            "Always respond in a conversational and emotionally intelligent tone, but keep answers clear and accurate. "
            f"Current date and time: {now}." 
        )

        # Add recent conversation context
        recent_conversations = history.get_recent_conversations(5)
        if recent_conversations:
            recent_context = " ".join([f"{c['role']}: {c['content']}" for c in recent_conversations])
            context += f" Recent conversation: {recent_context}"

        # Add to history
        history.add_conversation("user", question)

        # Generate response
        if "give me more" in question.lower() or "explain more" in question.lower():
            response = chat.send_message(context + " " + question)
        else:
            response = chat.send_message(
                context + " " + f"Answer concisely in one sentence: {question}"
            )

        answer = response.text
        
        # Add to history and memory
        history.add_conversation("assistant", answer)
        
        if learning:
            memory.learn_fact(question, answer)

        return answer

    except Exception as e:
        print(f"Gemini API error: {e}")
        return "Sorry, I'm having a little trouble connecting right now."

def ask_nox(question):
    """Retrieve knowledge first, then ask Gemini concisely by default."""
    # Check knowledge base first
    fact = memory.get_fact(question)
    if fact:
        return fact
        
    # For Long Responses
    if "give me more" in question.lower() or "explain more" in question.lower():
        response = chat.send_message(
            f"Answer the following question in detail and explain step by step: {question}"
        )
    else:
        response = chat.send_message(
            f"Answer the following question concisely and directly in one sentence: {question}"
        )
    answer = response.text

    # Save new info
    memory.learn_fact(question, answer)
    return answer