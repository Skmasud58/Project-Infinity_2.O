from core.memory import Memory

memory = Memory()

def learn_user_preference(topic, preference):
    """Learn and store user preferences"""
    memory.learn_fact(f"preference_{topic}", preference)
    
def get_user_preference(topic):
    """Retrieve user preference"""
    return memory.get_fact(f"preference_{topic}")

def learn_conversation_pattern(pattern, response):
    """Learn conversation patterns for better responses"""
    memory.learn_fact(f"pattern_{pattern}", response)