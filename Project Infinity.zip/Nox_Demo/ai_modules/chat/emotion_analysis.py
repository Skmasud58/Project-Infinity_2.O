import random

def emotional_response(user_input, ai_reply):
    if any(word in user_input for word in ["sad", "tired", "depressed", "upset"]):
        ai_reply += " Remember, I'm always here for you, okay?"
    elif any(word in user_input for word in ["happy", "excited", "great", "awesome"]):
        ai_reply += " That's fantastic! I'm really happy to hear that."
    elif any(word in user_input for word in ["angry", "mad", "frustrated"]):
        ai_reply += " Take a deep breath, buddy. Let's handle this calmly together."
    return ai_reply

def deep_emotional_response(command):
    """Detects deeply emotional or tragic events and responds with empathy."""
    from voice.speaker import speak
    
    tragic_keywords = [
        "accident", "death", "died", "passed away", "killed", "hospital",
        "injured", "hurt badly", "serious condition", "bad news", "emergency",
        "lost someone", "lost my friend", "lost my father", "lost my mother",
        "lost my brother", "lost my sister", "funeral"
    ]

    if any(word in command for word in tragic_keywords):
        responses = [
            "Oh no... I'm so sorry to hear that. That must be really painful. Are you okay?",
            "That's heartbreaking... I can't imagine how hard this must be for you. I'm right here if you need someone to talk to.",
            "That's really sad news… Sometimes, words can't fix pain, but please remember, you're not alone. I'm here, always.",
            "I wish I could give you a hug right now. I really mean it — please take care of yourself.",
            "That sounds really tough… If it helps, we can take a few deep breaths together. You don't have to say anything."
        ]
        speak(random.choice(responses))
        return True
    return False