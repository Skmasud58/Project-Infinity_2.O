import webbrowser
import pywhatkit
import os
from voice.speaker import speak

def play_song(song_name):
    """Play song on YouTube"""
    if song_name != "none":
        speak(f"Playing {song_name} on YouTube.")
        pywhatkit.playonyt(song_name)

def play_movies():
    """Search and play movies"""
    extensions = (".mp4", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".webm")
    drives = [f"{d}:\\" for d in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{d}:\\")]
    movies = [os.path.join(root, file) for drive in drives for root, _, files in os.walk(drive) for file in files if file.lower().endswith(extensions)]
    
    if movies:
        speak(f"Found {len(movies)} videos. Playing first one.")
        os.startfile(movies[0])
    else:
        speak("No movies found. Playing funny videos on YouTube.")
        webbrowser.open("https://www.youtube.com/results?search_query=funny+videos")

def open_website(url_name):
    """Open common websites"""
    websites = {
        "youtube": "https://youtube.com",
        "google": "https://google.com",
        "whatsapp": "https://web.whatsapp.com",
        "telegram": "https://web.telegram.org",
        "facebook": "https://facebook.com",
        "chatgpt": "https://chat.openai.com"
    }
    
    if url_name in websites:
        speak(f"Opening {url_name}...")
        webbrowser.open(websites[url_name])
    else:
        speak("Website not configured")