import pywhatkit
from voice.speaker import speak

def send_whatsapp_message(phone, message):
    """Send WhatsApp message"""
    try:
        pywhatkit.sendwhatmsg_instantly(phone, message)
        speak("WhatsApp message sent successfully")
    except Exception as e:
        speak(f"Failed to send WhatsApp message: {str(e)}")

def send_whatsapp_to_group(group_id, message):
    """Send message to WhatsApp group"""
    try:
        pywhatkit.sendwhatmsg_to_group(group_id, message)
        speak("Group message sent successfully")
    except Exception as e:
        speak(f"Failed to send group message: {str(e)}")