from utils.file_manager import FileManager

class DataInitializer:
    def __init__(self):
        self.file_manager = FileManager()
    
    def initialize_all(self):
        """Initialize all required files and directories"""
        print("Initializing Nox AI data structure...")
        
        # Create directories
        self.file_manager.ensure_directories()
        
        # Create files
        self.file_manager.ensure_files()
        
        # Create default log file
        log_file = self.file_manager.base_path / "logs" / "nox_activity.log"
        if not log_file.exists():
            log_file.touch()
        
        print("Nox AI data structure initialized successfully!")
        
    def check_data_integrity(self):
        """Verify all required files exist and are valid"""
        required_files = [
            "data/user_data.json",
            "data/reminders.json", 
            "data/conversation_history.json",
            "data/system_state.json",
            "data/nox_alarms.json",
            "data/nox_reminders.json",
            "data/used_jokes.json",
            "data/nox_knowledge.json"
        ]
        
        for file_path in required_files:
            if not Path(file_path).exists():
                return False
        
        return True