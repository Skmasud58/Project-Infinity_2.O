import requests
import socket
from voice.speaker import speak

def what_is_my_live_location():
    """Get approximate live location based on IP"""
    try:
        resp = requests.get("https://ipinfo.io/json")
        data = resp.json()
        loc = data.get("loc")  # e.g. "12.9716,77.5946"
        city = data.get("city")
        region = data.get("region")
        country = data.get("country")
        
        if loc:
            lat, lon = loc.split(",")
            return {
                "latitude": float(lat),
                "longitude": float(lon),
                "city": city,
                "region": region,
                "country": country
            }
        else:
            return None
    except Exception as e:
        print("[LiveLocation Error]", e)
        return None

def check_internet_connection():
    """Check if internet connection is available"""
    try:
        requests.get("https://www.google.com", timeout=5)
        return True
    except:
        return False

def get_public_ip():
    """Get public IP address"""
    try:
        response = requests.get("https://api.ipify.org", timeout=5)
        return response.text
    except:
        return None