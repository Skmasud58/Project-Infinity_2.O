import os
import json
import shutil
import string
import re
from pathlib import Path
import threading
from voice.speaker import speak

class FileManager:
    def __init__(self, base_path="data"):
        self.base_path = Path(base_path)
        self.lock = threading.RLock()
        self.ensure_directories()
        self.ensure_files()
    
    def ensure_directories(self):
        """Create all necessary directories"""
        directories = [
            self.base_path,
            self.base_path / "logs",
            self.base_path / "cache",
            Path("assets/sounds"),
            Path("assets/icons"),
            Path("assets/models")
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def ensure_files(self):
        """Create all necessary JSON files with default structure"""
        files_data = {
            "user_data.json": {
                "user_preferences": {},
                "custom_commands": {},
                "learned_patterns": {}
            },
            "reminders.json": {
                "reminders": [],
                "alarms": []
            },
            "conversation_history.json": {
                "sessions": [],
                "last_session_id": None
            },
            "system_state.json": {
                "last_activity": None,
                "current_context": {},
                "system_status": "ready"
            },
            "nox_alarms.json": [],
            "nox_reminders.json": [],
            "used_jokes.json": [],
            "nox_knowledge.json": {}
        }
        
        for filename, default_data in files_data.items():
            file_path = self.base_path / filename
            if not file_path.exists():
                self.write_json(file_path, default_data)
    
    def read_json(self, file_path, default=None):
        """Read JSON file with error handling"""
        if default is None:
            default = {}
        if not isinstance(file_path, Path):
            file_path = Path(file_path)
            
        if not file_path.exists():
            return default
            
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if not content:  # Handle empty files
                    return default
                return json.loads(content)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"[Load JSON Error] {file_path}: {e}")
            # Recreate the file with default data
            self.write_json(file_path, default)
            return default
    
    def write_json(self, file_path, data):
        """Write data to JSON file with error handling"""
        with self.lock:
            if not isinstance(file_path, Path):
                file_path = Path(file_path)
                
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                return True
            except Exception as e:
                print(f"Error writing to {file_path}: {e}")
                return False
    
    def file_exists(self, file_path):
        """Check if file exists"""
        return Path(file_path).exists()

def list_drives():
    """List all accessible drives A-Z"""
    drives = []
    for d in string.ascii_uppercase:
        drive_path = f"{d}:\\"
        if os.path.exists(drive_path):
            drives.append(drive_path)
    return drives

def open_path(path):
    """Open a folder, file, or drive"""
    if os.path.exists(path):
        os.startfile(path)
        speak(f"Opened {path}")
    else:
        speak(f"Path not found: {path}")

def create_folder(path):
    """Create a new folder"""
    os.makedirs(path, exist_ok=True)
    speak(f"Folder created at {path}")

def create_file(path, content=""):
    """Create a new file"""
    folder = os.path.dirname(path)
    if folder and not os.path.exists(folder):
        os.makedirs(folder)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    speak(f"File created at {path}")

def copy_file(src, dst):
    """Copy file from source to destination"""
    if os.path.exists(src):
        dst_folder = os.path.dirname(dst)
        if dst_folder and not os.path.exists(dst_folder):
            os.makedirs(dst_folder)
        shutil.copy2(src, dst)
        speak(f"Copied {os.path.basename(src)} to {dst}")
    else:
        speak("Source file not found.")

def search_files(name_keywords, extensions=None, max_depth=6):
    """Search files across all drives"""
    matches = []
    for drive in list_drives():
        for root, _, files in os.walk(drive):
            depth = root.replace(drive, "").count(os.sep)
            if depth > max_depth:
                continue 
            for f in files:
                lower_f = f.lower()
                if all(k.lower() in lower_f for k in name_keywords):
                    if not extensions or any(lower_f.endswith(ext) for ext in extensions):
                        matches.append(os.path.join(root, f))
    return matches

def handle_file_command(command):
    """Handle file operations from voice commands"""
    command = command.lower().strip()

    # Open Drive
    match_drive = re.search(r"open\s+([a-z])\s*drive", command)
    if match_drive:
        drive_letter = match_drive.group(1).upper()
        drive_path = f"{drive_letter}:\\"
        if os.path.exists(drive_path):
            open_path(drive_path)
        else:
            speak(f"{drive_letter} drive not found.")
        return True

    # Open Folder
    if "open folder" in command:
        for drive in list_drives():
            if drive[0].lower() in command:
                folder_name = command.split("folder")[-1]
                folder_name = re.sub(r"(in|drive|"+drive[0].lower()+")", "", folder_name)
                folder_name = folder_name.strip().replace(" ", "\\")
                folder_path = os.path.join(drive, folder_name)
                open_path(folder_path)
                return True

    # Create Folder
    if "create folder" in command:
        parts = command.split("create folder")[-1].strip()
        if "in" in parts:
            folder_name, drive_part = parts.split("in", 1)
            folder_name = folder_name.strip().replace(" ", "\\")
            drive_letter = drive_part.strip()[0].upper()
            folder_path = os.path.join(f"{drive_letter}:\\", folder_name)
            create_folder(folder_path)
            return True

    # Create File
    if "create file" in command:
        parts = command.split("create file")[-1].strip()
        if "in" in parts:
            file_name, drive_part = parts.split("in", 1)
            file_name = file_name.strip()
            drive_letter = drive_part.strip()[0].upper()
            file_path = os.path.join(f"{drive_letter}:\\", file_name)
            create_file(file_path)
            return True

    # Copy File
    if "copy file" in command and "to" in command:
        try:
            src_part = command.split("copy file")[-1].split("to")[0].strip()
            dst_part = command.split("to")[-1].strip()
            copy_file(src_part, dst_part)
            return True
        except Exception as e:
            speak(f"Copy failed: {e}")
            return True

    # Search Files
    if "pdf" in command or "document" in command:
        keywords = [w for w in command.split() if w not in {"give", "me", "my", "pdf", "document", "file"}]
        extensions = [".pdf"] if "pdf" in command else None
        results = search_files(keywords, extensions)
        if results:
            speak(f"I found {len(results)} matching file(s). Opening the best match.")
            open_path(results[0])
        else:
            speak("No matching document found.")
        return True

    return False