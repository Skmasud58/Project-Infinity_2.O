import requests
import feedparser
import pyautogui
import random
import pyjokes
import json
import os
from datetime import datetime
from config.settings import WEATHER_API_KEY, NEWS_API_KEY, USED_JOKES_FILE

def get_weather(city):
    """Get weather information for a city"""
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric"
    try:
        data = requests.get(url).json()
        if data.get("cod") != 200:
            return "City not found."
        temp = data["main"]["temp"]
        desc = data["weather"][0]["description"]
        return f"Temperature: {temp}°C, Weather: {desc}"
    except Exception as e:
        return f"Error fetching weather: {str(e)}"

def fetch_news():
    """Fetch latest news headlines"""
    try:
        rss_url = "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en"
        feed = feedparser.parse(rss_url)
        return [entry.title for entry in feed.entries[:5]]
    except Exception as e:
        print(f"News fetch error: {e}")
        return ["Unable to fetch news at the moment"]

def take_screenshot():
    """Take screenshot and save to Downloads"""
    screenshot = pyautogui.screenshot()
    downloads = os.path.join(os.path.expanduser("~"), "Downloads")
    os.makedirs(downloads, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(downloads, f"screenshot_{timestamp}.png")
    screenshot.save(path)
    return path

def get_real_time():
    """Get current real time"""
    try:
        response = requests.get("https://worldtimeapi.org/api/ip", timeout=5)
        data = response.json()
        return datetime.fromisoformat(data["datetime"][:-1])
    except:
        return datetime.now()

def tell_joke():
    """Tell a random unique joke"""
    used_jokes = load_used_jokes()
    all_jokes = pyjokes.get_jokes(language="en", category="all")
    remaining_jokes = [j for j in all_jokes if j not in used_jokes]
    
    if not remaining_jokes:
        used_jokes = []
        remaining_jokes = all_jokes
        save_used_jokes(used_jokes)
        return "Haha, I've told all my jokes already! Resetting my comedy circuits now!"
    
    joke = random.choice(remaining_jokes)
    used_jokes.append(joke)
    save_used_jokes(used_jokes)
    
    comments = [
        "Haha, that one's good!",
        "I'm cracking up over this!",
        "That was a classic one!",
        "I bet you didn't see that coming!",
        "Haha, my circuits can't stop laughing!",
        "That one never gets old!",
        "I might use that one next time someone asks me to debug their mood!"
    ]
    
    return f"{joke} {random.choice(comments)}"

def load_used_jokes():
    """Load used jokes from file"""
    if os.path.exists(USED_JOKES_FILE):
        try:
            with open(USED_JOKES_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError:
            return []
    return []

def save_used_jokes(jokes):
    """Save used jokes to file"""
    with open(USED_JOKES_FILE, "w", encoding="utf-8") as f:
        json.dump(jokes, f, indent=2)