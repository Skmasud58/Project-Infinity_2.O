# API Keys
GEMINI_API_KEY = "AIzaSyAJ_cpEJymCEanXG1VdHgkRZdEh0Kgn3Rc"
NEWS_API_KEY = "73ce9099027347c78cacf8960902d2c5"
WEATHER_API_KEY = "e7704bc895b4a8d2dfd4a29d404285b6"
SERP_API_KEY = "717f13e949e195eae93123f24b8337f460e5a3f1562b7dbe60a67adbb6678864"
METAL_API_KEY = "884425ab49b2c89b6aff831384b1e705"

# Email Configuration
EMAIL_ADDRESS = "skmasudrahaman58@gmail.com"
EMAIL_PASSWORD = "bzbkuoizpxunlvix"

# File Paths
HISTORY_FILE = "data/conversation_history.json"
KNOWLEDGE_FILE = "data/nox_knowledge.json"
ALARM_FILE = "data/nox_alarms.json"
REMINDER_FILE = "data/nox_reminders.json"
USED_JOKES_FILE = "data/used_jokes.json"

# Wake Words
WAKE_WORDS = ["hay nox", "hay knos", "knox", "nox", "Inox", "wake up"]

# Contacts
CONTACTS = {
    "abba": "skmajaffarrahaman1977@gmail.com",
    "ma": "manuarakhatun1980@gmail.com",
    "sk": "mrskmasudrahaman@gmail.com",
}

# System Settings
ALARM_SOUND = "assets/sounds/alarm_sound.mp3"
LAUGH_SOUND = "assets/sounds/laugh.mp3"