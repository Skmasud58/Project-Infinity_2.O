# Voice Settings
VOICE_RATE = "+10%"
VOICE_NAME = "en-IN-ArjunNeural"
LANGUAGE = "en-in"

# Speech Recognition Settings
LISTENER_TIMEOUT = 5
PHRASE_TIME_LIMIT = 10
PAUSE_THRESHOLD = 1