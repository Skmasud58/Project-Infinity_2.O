import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
from datetime import datetime

class NoxDashboard:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Nox AI Dashboard")
        self.root.geometry("800x600")
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Status section
        status_frame = ttk.LabelFrame(main_frame, text="System Status", padding="5")
        status_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=5)
        
        self.status_label = ttk.Label(status_frame, text="Status: Ready")
        self.status_label.grid(row=0, column=0, sticky=tk.W)
        
        # Conversation log
        log_frame = ttk.LabelFrame(main_frame, text="Conversation Log", padding="5")
        log_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, width=80)
        self.log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Controls frame
        controls_frame = ttk.LabelFrame(main_frame, text="Quick Controls", padding="5")
        controls_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Button(controls_frame, text="View Alarms", command=self.view_alarms).grid(row=0, column=0, padx=5)
        ttk.Button(controls_frame, text="View Reminders", command=self.view_reminders).grid(row=0, column=1, padx=5)
        ttk.Button(controls_frame, text="System Info", command=self.show_system_info).grid(row=0, column=2, padx=5)
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
    def view_alarms(self):
        """Show active alarms"""
        from ai_modules.productivity.alarm import list_active_alarms
        alarms = list_active_alarms()
        
        alarm_window = tk.Toplevel(self.root)
        alarm_window.title("Active Alarms")
        alarm_window.geometry("400x300")
        
        text = scrolledtext.ScrolledText(alarm_window, width=50, height=15)
        text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        if alarms:
            text.insert(tk.END, "\n".join(alarms))
        else:
            text.insert(tk.END, "No active alarms")
        text.config(state=tk.DISABLED)
        
    def view_reminders(self):
        """Show active reminders"""
        from ai_modules.productivity.reminder import list_active_reminders
        reminders = list_active_reminders()
        
        reminder_window = tk.Toplevel(self.root)
        reminder_window.title("Active Reminders")
        reminder_window.geometry("400x300")
        
        text = scrolledtext.ScrolledText(reminder_window, width=50, height=15)
        text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        if reminders:
            text.insert(tk.END, "\n".join(reminders))
        else:
            text.insert(tk.END, "No active reminders")
        text.config(state=tk.DISABLED)
        
    def show_system_info(self):
        """Display system information"""
        from ai_modules.system.system_info import system_info
        system_info()
        
    def log_message(self, role, message):
        """Add message to conversation log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {role}: {message}\n"
        
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        
    def run(self):
        """Start the dashboard"""
        self.root.mainloop()

def start_dashboard():
    """Start the Nox dashboard in a separate thread"""
    dashboard = NoxDashboard()
    dashboard.run()