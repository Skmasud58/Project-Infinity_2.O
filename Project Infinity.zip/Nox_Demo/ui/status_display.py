import tkinter as tk
from tkinter import ttk
import psutil
import threading
import time

class StatusDisplay:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Nox Status Monitor")
        self.root.geometry("300x200")
        self.setup_ui()
        
    def setup_ui(self):
        # CPU Usage
        ttk.Label(self.root, text="CPU Usage:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.cpu_var = tk.StringVar(value="0%")
        ttk.Label(self.root, textvariable=self.cpu_var).grid(row=0, column=1, sticky=tk.W, padx=5, pady=2)
        
        # Memory Usage
        ttk.Label(self.root, text="Memory Usage:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.mem_var = tk.StringVar(value="0%")
        ttk.Label(self.root, textvariable=self.mem_var).grid(row=1, column=1, sticky=tk.W, padx=5, pady=2)
        
        # Battery
        ttk.Label(self.root, text="Battery:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
        self.battery_var = tk.StringVar(value="Unknown")
        ttk.Label(self.root, textvariable=self.battery_var).grid(row=2, column=1, sticky=tk.W, padx=5, pady=2)
        
        # Status
        ttk.Label(self.root, text="Status:").grid(row=3, column=0, sticky=tk.W, padx=5, pady=2)
        self.status_var = tk.StringVar(value="Listening...")
        ttk.Label(self.root, textvariable=self.status_var).grid(row=3, column=1, sticky=tk.W, padx=5, pady=2)
        
        self.update_stats()
        
    def update_stats(self):
        """Update system statistics"""
        # CPU
        cpu_percent = psutil.cpu_percent()
        self.cpu_var.set(f"{cpu_percent}%")
        
        # Memory
        memory = psutil.virtual_memory()
        self.mem_var.set(f"{memory.percent}%")
        
        # Battery
        battery = psutil.sensors_battery()
        if battery:
            status = "Charging" if battery.power_plugged else "Discharging"
            self.battery_var.set(f"{battery.percent}% ({status})")
        else:
            self.battery_var.set("No battery")
            
        # Schedule next update
        self.root.after(2000, self.update_stats)
        
    def set_status(self, status):
        """Update status message"""
        self.status_var.set(status)
        
    def run(self):
        """Start the status display"""
        self.root.mainloop()